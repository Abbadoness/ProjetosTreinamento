import './App.css';

import { Switch, Route} from "react-router-dom";
import PagLogin from "../src/pages/login"
import PagCadastro from "../src/pages/cadastro"
import HomePage from "../src/pages/homePage"
import BackOfficeCreateMealCategory from "../src/pages/BackOfficeCreateMealCategoryPage"
import BackOfficeCreateMeal from "../src/pages/BackOfficeCreateMealPage"
import BackOfficeEditOrder from "../src/pages/BackOfficeEditOrderPage"
import BackOfficeEditUser from "../src/pages/BackOfficeEditUserPage"

import { BrowserRouter } from 'react-router-dom';

function App() {
    return (
      <BrowserRouter>
        <Switch>
            <Route path="/" component={HomePage} exact />
            <Route path="/login" component={PagLogin}  exact />
            <Route path="/cadastro" component={PagCadastro}  exact />
            <Route path='/backoffice/category/create' component={BackOfficeCreateMealCategory} exact />
            <Route path='/backoffice/meal/create' component={BackOfficeCreateMeal} exact />
            <Route path='/backoffice/order/edit' component={BackOfficeEditOrder} exact />
            <Route path='/backoffice/user/edit' component={BackOfficeEditUser} exact />
        </Switch>
      </BrowserRouter>
    );
}

export default App;