import './styles.css';
import React, { useState } from 'react';

export function DropdownSelect({ label, placeholder, list }) {
    const [selected, setSelected] = useState("");

    const handleSelectChange = (e) => {
        setSelected(e.target.value)
    }

    return (
        <div className='dropdownSelect'>
            <label className='input_label'>{label}</label> <br className='brInputComponents' />
            <section className="wrapper">
                <select className='select_box' value={selected} onChange={handleSelectChange}>
                    <option value='' disabled hidden>{placeholder}</option>
                    {list.map((selected) => <option key={selected} value={selected}>{selected}</option>)}
                </select>
            </section>
        </div >
    )
}