import './styles.css';
import React from 'react';

export function InputWithButton({ label, placeholder, type, disabled, buttonLabel,  defaultValue, onBlurFunction, showLabel}) {
    return (
        <div className='inputWithButton'>
            {showLabel && <div> <label className='input_label'>{label}</label> <br className='brInputComponents' /> </div>}
            <input className='input_box_with_button' type={type} placeholder={placeholder} disabled={disabled} defaultValue={defaultValue} onBlur={onBlurFunction}/>
            <button className='input_button' type="button" disabled={disabled}>{buttonLabel} </button>
        </div>
    )
}