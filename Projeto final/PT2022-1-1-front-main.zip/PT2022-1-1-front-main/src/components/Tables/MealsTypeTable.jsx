import { Table } from './Table'

function Row ({rowData}) {
    function deleteMealType(deletedMealTypeId) {}

    return (
        <tr className="trBody">
            <td className="td">{rowData.name}</td>
            <td className="td">{rowData.quantity} </td>
            <td className="td">{rowData.created_at}</td>
            <td className="actions_buttons">
                <button className="edit_button">editar</button>
                <button className="delete_button" onClick= {() => deleteMealType(rowData.id)}>excluir</button>
            </td>
        </tr>
    )
}

export function MealsTypeTable({mealsType}) {
    return <Table Row = {Row} data = {mealsType} title = {['Nome', 'Número de Refeições', 'Cadastrada em', '', '']}/>
} 