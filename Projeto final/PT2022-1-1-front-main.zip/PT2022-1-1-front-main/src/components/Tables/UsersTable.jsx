import { isValidDateValue } from '@testing-library/user-event/dist/utils'
import { StatusCell } from '../StatusCell'
import { Table } from './Table'

function Row ({rowData}) {

    function deleteUser(deletedUserId) {}

    return (
        <tr className="trBody">
            <td className="tdName">{rowData.isAdmin ? <StatusCell status='admin'/> : <></>} {rowData.name}</td>
            <td className="td">{rowData.email}</td>
            <td className="td">{rowData.created_at}</td>
            <td className="actions_buttons">
                <button className="edit_button">editar</button>
                <button className="delete_button" onClick= {() => deleteUser(rowData.id)}>excluir</button>
            </td>
        </tr>
    )
}

export function UsersTable({users}) {
    return <Table Row = {Row} data = {users} title = {['Nome', 'Email', 'Cadastrado em', '', '']}/>
} 