import { Table } from './Table'
import { EditButton, DeleteButton, ViewButton } from '../TextButtons'

function Row ({rowData}) {

    function deleteOrder(OrderId) {}
    function viewOrder(OrderId) {}
    function editOrder(OrderId) {}

    return (
        <tr className="trBody">
            <td className="td">{rowData.orderNumber}</td>
            <td> {(() => {
                if (rowData.status === "Entregue")
                return (<td className="Entregue"> entregue </td>)
                else if (rowData.status === "Pendente")
                    return (<td className="Pendente"> pendente </td>)
                else
                    return (<td className="Cancelado"> cancelado </td>)
                    })()}</td>
            <td className="td">{rowData.created_at}</td>
            <td className="td">{rowData.user}</td>
            <td className="td">{rowData.price}</td>
            <td className="actions_buttons">
                <ViewButton viewAction={() => viewOrder(rowData.id)}/>
                <EditButton editAction={() => editOrder(rowData.id)}/>
                <DeleteButton deleteAction={() => deleteOrder(rowData.id)}/>
            </td>
        </tr>
    )
}

export function OrdersTable({orders}) {
    return <Table Row = {Row} data = {orders} title = {['Pedido n°','Status','Data','Usuário','Preço total','Detalhes','','']}/>
} 