import './styles.css';
import { useState, useEffect } from "react"

export const Table = ({Row, data, title}) => {

	const ITEMS_PER_PAGE = 5

	const [arr, setArr] = useState([])
	const [currentPage, setCurrentPage] = useState(1)                     // Pagina atual (inicial = 1)

	useEffect(() => {
		setArr(data)
	}, [data])

	const startIndex = (currentPage -1) * ITEMS_PER_PAGE
	const endIndex = startIndex + ITEMS_PER_PAGE
	
	function createNumberedArray(num) {
		return [...Array(num).keys()]
	}

	const totalNumberOfPages = Math.ceil(data.length/ITEMS_PER_PAGE)

	return (
		<div className='container'>
			<table className="table">
					<tr className="trHead">
						{title.map(th => {
							return (
								<th className="th">{th}</th>
							)
						})}
					</tr>
				<tbody className="tbody">
					{arr.slice(startIndex, endIndex).map((rowData, index) => {
					return (
					<Row key = {index} rowData = {rowData}/> 
					)})}
				</tbody>
			</table>
			<div className='pagination'>
				<div className='prev_page_button' onClick={() => setCurrentPage(Math.max(1, (currentPage-1)))}>{'<<'}</div>
				{createNumberedArray(totalNumberOfPages).map((e, index) => 
					<div className={'numbered_page_button' + (currentPage === index+1 ? '_current': '')} onClick={() => setCurrentPage(index+1)}>{index+1}</div>
				)}
				<div className='next_page_button' onClick={() => setCurrentPage(Math.min(totalNumberOfPages, (currentPage+1)))}>{'>>'}</div>
			</div>
		</div>
	);
}