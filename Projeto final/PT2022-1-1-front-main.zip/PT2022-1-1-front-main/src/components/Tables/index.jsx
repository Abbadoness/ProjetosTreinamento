export { UsersTable } from './UsersTable'
export { MealsTypeTable } from './MealsTypeTable'
export { OrdersTable } from './OrdersTable'

/*------------- PARA USAR AS TABELAS, SEGUE EXEMPLO ABAIXO: ------------------ */

// import {UsersTable, MealsTypeTable, OrdersTable} from './components/Tables'




// let users = [
//     {id:1,name:"Lauren",email:"lshaxby0@php.net",created_at:"16/10/2021", isAdmin: true},
//     {id:2,name:"Ardenia",email:"apaddingdon1@nsw.gov.au",created_at:"27/07/2021", isAdmin: true},
//     {id:3,name:"Renaldo",email:"ralenichev2@ftc.gov",created_at:"10/06/2021", isAdmin: false},
//     {id:4,name:"Nichole",email:"noheneghan3@flavors.me",created_at:"28/06/2021", isAdmin: false},
//     {id:5,name:"Haywood",email:"hdaintry4@nhs.uk",created_at:"18/03/2021", isAdmin: false},
//     {id:6,name:"Leslie",email:"ldaile5@vimeo.com",created_at:"23/05/2021", isAdmin: false}, 
//     {id:7,name:"Byrann",email:"bslorance6@kickstarter.com",created_at:"15/05/2021", isAdmin: true},
//     {id:8,name:"My",email:"mswendell7@moonfruit.com",created_at:"15/12/2021", isAdmin: false},
//     {id:9,name:"Brier",email:"besson8@usa.gov",created_at:"14/03/2021", isAdmin: true},
//     {id:10,name:"Seth",email:"spiddle9@nationalgeographic.com",created_at:"20/10/2021", isAdmin: false},
//     {id:11,name:"Fer",email:"ferspiddle9@nationalgeographic.com",created_at:"20/10/2022", isAdmin: false}
// ]

// let mealsType = [
//     {id:1,name:"Saladas",quantity:4,created_at:"16/10/2021"},
//     {id:2,name:"Molhos",quantity:4,created_at:"27/07/2021"},
//     {id:3,name:"Pratos Principais",quantity:4,created_at:"10/06/2021"},
//     {id:4,name:"Guarnições",quantity:4,created_at:"28/06/2021"},
//     {id:5,name:"Bebidas",quantity:4,created_at:"18/03/2021"},
//     {id:6,name:"Carnes",quantity:4,created_at:"23/05/2021"}, 
//     {id:7,name:"Sucos",quantity:4,created_at:"15/05/2021"},
// ]

// let orders = [
//   {id:1,orderNumber:"103849",status:"Entregue",created_at:"16/10/2021", user: "Fulano", price: "R$ 10,05"},
//   {id:2,orderNumber:"103849",status:"Pendente",created_at:"27/07/2021", user: "Fulano", price: "R$ 30,50"},
//   {id:3,orderNumber:"103849",status:"Cancelado",created_at:"10/06/2021", user: "Fulano", price: "R$ 90,12"},
//   {id:4,orderNumber:"103849",status:"Entregue",created_at:"28/06/2021", user: "Fulano", price: "R$ 145,15"},
//   {id:5,orderNumber:"103849",status:"Entregue",created_at:"18/03/2021", user: "Fulano", price: "R$ 99,99"},
//   {id:6,orderNumber:"103849",status:"Entregue",created_at:"23/05/2021", user: "Fulano", price: "R$ 15,51"}, 
//   {id:7,orderNumber:"103849",status:"Entregue",created_at:"15/05/2021", user: "Fulano", price: "R$ 15,51"}
// ]



//   return (
//     <div>
//       <UsersTable users = {users}/>
//       <br/>
//       <MealsTypeTable mealsType = {mealsType}/>
//       <br/>
//       <OrdersTable orders = {orders}/>
//     </div>
//   );
//}