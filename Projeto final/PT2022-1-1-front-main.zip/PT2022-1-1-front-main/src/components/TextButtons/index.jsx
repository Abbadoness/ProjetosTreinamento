import './styles.css';
import React from 'react';

export function EditButton({editAction}) {
    return (<button className="edit_button" onClick= {editAction}>editar</button>)
}

export function DeleteButton({deleteAction}) {
    return (<button className="delete_button" onClick= {deleteAction}>excluir</button>)
}

export function ViewButton({viewAction}) {
    return (<button className="view_button" onClick= {viewAction}>ver itens pedidos</button>)
}