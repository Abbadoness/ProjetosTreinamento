import './styles.css';
import React from 'react';

export function Footer() {
    return (
        <div className='footer'>
            <div className='container'>
                <div className='text'>dinnerdash | todos os direitos reservados</div>
                <div className='text'>desenvolvido pelo melhor núcleo aka NDP</div>
            </div>
        </div>
    )
}