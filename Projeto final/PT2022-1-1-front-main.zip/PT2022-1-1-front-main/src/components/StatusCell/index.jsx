import './styles.css';
import React from 'react';

export function StatusCell({status}) {
    return (
        /* status pode ser 'admin' ou 'entregue' ou 'pendente' ou 'cancelado'. 
        admin torna a celula menor, pendente tem background-color azul,
        cancelado tem background-color vermelho. qualquer outra string
        retorna tamanho e cor padrao (verde). exemplo:
        <StatusCell status='pendente'> */
        <div className={'status_cell_' + status}>
            {status}
        </div>
    )
}