import React from 'react';
import "./styles.css";

import Imagem from "../../assets/22.jpeg";

const CardRefeicao = ({name,description,value,available,...props}) => {
    
    function editMeal(){}
    function deleteMeal(){}

    return (
        <>
        <div className="container-CardPrincipal">

            <div className="container-Imagem">
                <img src={Imagem} alt="Imagem da refeição" className={available ? "Imagem" : "Imagem img-indisponivel"}/>
                <div> {available ? <></> : <div class="indisponivel">Refeição indisponível</div>}</div>
                <div className="name">{name}</div>
            </div>

            <div className="description">{description}</div>
            <div className="value">{value}</div>
            <div className="actionButtons">
                <button class = "editBgButton" onClick={editMeal}>editar</button>
                <button class = "deleteBgButton" onClick={deleteMeal}>excluir</button>
            </div>
        </div>
        </>
    )
}

export default CardRefeicao;