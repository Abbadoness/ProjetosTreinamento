import React from "react";
import Fundo from "../../assets/background-img.jpg";
import "./styles.css";
import Botao from "../../components/Button";
import Input from "../../components/Input"

const PagLogin = () => {
  return (
    <>
      <div className="maior-login">
        <img src={Fundo} alt="foto de fundo" className="img-login" />
        <div className="login_container">
          <form className="login-form">
          <h1 className="login_title">dinnerdash</h1>
            <Input label="Email" type="email"/>
            <Input label="Senha" type="password"/>
            <Botao children="Entrar" width="100%" className="fundoVerde" />
            <div className="linha"/>
            <div className="no_conta">
              <p>Não possui conta?</p>
              <Botao children="Cadastrar" width="100%" className="bordaVerde" />
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default PagLogin;
