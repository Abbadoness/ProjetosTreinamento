import React from "react";
import { Navbar } from "../../components/Navbar";
import "./styles.css";
import Input from "../../components/Input";
import { InputWithButton } from "../../components/InputWithButton";
import { DropdownSelect } from "../../components/DropdownSelect";
import Botao from "../../components/Button";
import { Footer } from "../../components/Footer";

export default function RefeicaoBackOfficePage() {
  return (
    <>
      <Navbar
        headerText="Backoffice"
        headerSubtext="Gerencie pedidos,refeições e mais."
        upperLinkObject={[
          { title: "backoffice", href: "#", active: true },
          { title: "perfil", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
        ]}
        backofficeLinkObject={[
          { title: "Pedidos", href: "#", active: false },
          { title: "Usuários", href: "#", active: false },
          { title: "Refeições", href: "#", active: true },
          { title: "Categorias de Refeições", href: "#", active: false },
        ]}
        type="backoffice"
      />

      <div className="metade_inferior_container">
        <div className="nova_refeicao">Nova refeição</div>

        <div className="linha" />

        <div className="container_inputs">
          <div className="nome_display">
            <Input label="nome" />

            <DropdownSelect label="categoria" list={["saladas", "molhos"]} />
          </div>

          <div className="segunda_camada">
            <Input label="Descrição" type="box" disabled={false} />

            <div className="preco_foto">
              <Input label="Preço" />

              <InputWithButton label="Foto" buttonLabel="Procurar" />
            </div>
            <div className="botoes">
              <Botao
                width="142px"
                height="55px"
                children="Voltar"
                className="fundoCinza"
              />

              <Botao
                width="363px"
                height="55px"
                children="Criar refeição"
                className="fundoVerde"
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}