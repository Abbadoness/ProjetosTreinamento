import React from "react";
import { Navbar } from "../../components/Navbar";
import "./styles.css";
import Input from "../../components/Input";
import { DropdownSelect } from "../../components/DropdownSelect";
import Botao from "../../components/Button";
import { Footer } from "../../components/Footer";

export default function BackOfficeEditOrderPage() {
  return (
    <>
      <Navbar
        headerText="Backoffice"
        headerSubtext="Gerencie pedidos,refeições e mais."
        upperLinkObject={[
          { title: "backoffice", href: "#", active: true },
          { title: "perfil", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
        ]}
        backofficeLinkObject={[
          { title: "Pedidos", href: "#", active: true },
          { title: "Usuários", href: "#", active: false },
          { title: "Refeições", href: "#", active: false },
          { title: "Categorias de Refeições", href: "#", active: false },
        ]}
        type="backoffice"
      />

      <div className="metade_inferior_container">
        <div className="nova_pedido">Editar pedido</div>

        <div className="linha" />

        <div className="container_inputs">
          <div className="numero_display">
            <Input label="Número" />

            <DropdownSelect label="Status" list={["Pendente", "Ativo"]} />
          </div>

          <div className="segunda_camada">

            <div className="data_usuario">
              <Input label="Data"/>

              <Input label="Usuário"/>
            </div>

            <div className="preco_total">
              <Input label="Preço total" />
            </div>

            <div className="botoes">
              <Botao
                width="142px"
                height="55px"
                children="Voltar"
                className="fundoCinza"
              />

              <Botao
                width="363px"
                height="55px"
                children="Salvar"
                className="fundoVerde"
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}