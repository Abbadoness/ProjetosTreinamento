import React from "react";
import Fundo from "../../assets/background-img.jpg";
import "./styles.css";
import Botao from "../../components/Button";
import Input from "../../components/Input"

const PagCadastro = () => {
  return (
    <>
      <div className="maior-cadastro">
        <img src={Fundo} alt="foto de fundo" className="img-cadastro"/>
        <div className="cadastro_container">
          <form className="cadastro-form">
          <h1 className="cadastro_title">dinnerdash</h1>
            <Input label="Nome" type="name"/>
            <Input label="Email" type="email"/>
            <Input label="Senha" type="password"/>
            <Input label="Confirme sua senha" type="password"/>
            <Botao children="Cadastrar" width="100%" className="fundoVerde" />
            <div className="linha"/>
            <div className="tem_conta">
              <p>Já possui conta?</p>
              <Botao children="Entrar" width="100%" className="bordaVerde" />
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default PagCadastro;
