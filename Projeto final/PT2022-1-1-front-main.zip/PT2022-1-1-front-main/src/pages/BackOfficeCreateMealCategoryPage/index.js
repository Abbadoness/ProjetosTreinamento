import React from "react";
import { Navbar } from "../../components/Navbar";
import "./styles.css";
import Input from "../../components/Input";
import Botao from "../../components/Button";
import { Footer } from "../../components/Footer";

export default function BackOfficeCreateMealCategoryPage() {
  return (
    <>
      <Navbar
        headerText="Backoffice"
        headerSubtext="Gerencie pedidos,refeições e mais."
        upperLinkObject={[
          { title: "backoffice", href: "#", active: true },
          { title: "perfil", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
        ]}
        backofficeLinkObject={[
          { title: "Pedidos", href: "#", active: false },
          { title: "Usuários", href: "#", active: false },
          { title: "Refeições", href: "#", active: false },
          { title: "Categorias de Refeições", href: "#", active: true },
        ]}
        type="backoffice"
      />

      <div className="metade_inferior_container">
        <div className="nova_pedido">Nova categoria de refeição</div>

        <div className="linha" />

        <div className="container_inputs">
          <div className="nome_display">
            <Input label="Nome" />
          </div>

          <div className="segunda_camada">

            <div className="botoes">
              <Botao
                width="142px"
                height="55px"
                children="Voltar"
                className="fundoCinza"
              />

              <Botao
                width="363px"
                height="55px"
                children="Criar categoria de refeição"
                className="fundoVerde"
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}