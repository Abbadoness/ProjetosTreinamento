import React from "react";
import { Navbar } from "../../components/Navbar";
import "./styles.css";
import Input from "../../components/Input";
import { DropdownSelect } from "../../components/DropdownSelect";
import Botao from "../../components/Button";
import { Footer } from "../../components/Footer";

export default function BackOfficeEditUserPage() {
  return (
    <>
      <Navbar
        headerText="Backoffice"
        headerSubtext="Gerencie pedidos,refeições e mais."
        upperLinkObject={[
          { title: "backoffice", href: "#", active: true },
          { title: "perfil", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
          { title: "meus pedidos", href: "#", active: false },
        ]}
        backofficeLinkObject={[
          { title: "Pedidos", href: "#", active: false },
          { title: "Usuários", href: "#", active: true },
          { title: "Refeições", href: "#", active: false },
          { title: "Categorias de Refeições", href: "#", active: false },
        ]}
        type="backoffice"
      />

      <div className="metade_inferior_container">
        <div className="editar_usuario">Editar usuário</div>

        <div className="linha" />

        <div className="container_inputs">
          <div className="nome_permissoes_display">
            <Input label="Nome" type="name"/>

            <DropdownSelect label="Permissões" list={["Administrador", "Cliente", "Visitante"]} />
          </div>

          <div className="segunda_camada">

            <div className="email_cadastrado">
              <Input label="Email" type="email"/>

              <Input label="Cadastrado em"/>
            </div>

            <div className="botoes">
              <Botao
                width="142px"
                height="55px"
                children="Voltar"
                className="fundoCinza"
              />

              <Botao
                width="363px"
                height="55px"
                children="Salvar"
                className="fundoVerde"
              />
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}